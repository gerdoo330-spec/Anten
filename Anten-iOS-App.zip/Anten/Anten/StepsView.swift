import SwiftUI

struct StepsView: View {
    @EnvironmentObject var state: AppState
    @State private var confirmReset = false

    private var progress: Double { Double(state.done.count) / Double(Step.all.count) }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    header
                    ForEach(Step.all) { step in
                        StepCard(step: step)
                    }
                    Text("این راهنما برای فعال‌سازی اینترنت از طریق اتصال 4G تهیه شده است. تنظیمات APN ممکن است بسته به اپراتور یا مدل دستگاه متفاوت باشد.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.leading)
                        .padding(.top, 8)
                }
                .padding()
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("بازگشت آنتن")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button { confirmReset = true } label: { Image(systemName: "arrow.uturn.backward") }
                        .disabled(state.done.isEmpty)
                }
            }
            .confirmationDialog("پیشرفت مراحل پاک شود؟", isPresented: $confirmReset, titleVisibility: .visible) {
                Button("پاک کردن", role: .destructive) { state.resetProgress() }
                Button("انصراف", role: .cancel) {}
            }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(systemName: "antenna.radiowaves.left.and.right")
                    .font(.title2).foregroundStyle(.white)
                    .frame(width: 48, height: 48)
                    .background(LinearGradient(colors: [.accentColor, .cyan], startPoint: .top, endPoint: .bottom),
                                in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                VStack(alignment: .leading, spacing: 2) {
                    Text("پروفایل APN آیفون").font(.headline)
                    Text("آیفون ۱۴ تا ۱۷ • iOS 16 به بعد").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
            }
            ProgressView(value: progress)
            Text("\(state.done.count.formatted()) از \(Step.all.count.formatted()) مرحله انجام شد")
                .font(.caption).foregroundStyle(.secondary)
        }
        .padding()
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}

struct StepCard: View {
    @EnvironmentObject var state: AppState
    let step: Step

    var body: some View {
        let done = state.isDone(step.id)
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                Image(systemName: step.icon)
                    .foregroundStyle(Color.accentColor)
                    .frame(width: 32, height: 32)
                    .background(Color.accentColor.opacity(0.12), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                Text("\((step.id + 1).formatted()). \(step.title)")
                    .font(.headline)
                Spacer()
                Button { state.toggle(step.id) } label: {
                    Image(systemName: done ? "checkmark.circle.fill" : "circle")
                        .font(.title2)
                        .foregroundStyle(done ? Color.green : Color.secondary)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(done ? "انجام شده" : "انجام نشده")
            }

            VStack(alignment: .leading, spacing: 6) {
                ForEach(step.lines, id: \.self) { line in
                    HStack(alignment: .firstTextBaseline, spacing: 6) {
                        Text("•").foregroundStyle(.secondary)
                        Text(line).font(.subheadline).foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
            }

            switch step.kind {
            case .generate: GenerateSection()
            case .airplane: AirplaneSection()
            case .shortcut: ShortcutSection()
            case .info: EmptyView()
            }
        }
        .padding()
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .opacity(done ? 0.7 : 1)
        .animation(.easeInOut(duration: 0.2), value: done)
    }
}

// MARK: - ساخت پروفایل

struct GenerateSection: View {
    @EnvironmentObject var state: AppState

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("اپراتور").font(.subheadline.weight(.semibold))
                Spacer()
                Picker("اپراتور", selection: $state.carrier) {
                    ForEach(Carrier.allCases) { c in
                        Text("\(c.persianName) (\(c.englishName))").tag(c)
                    }
                }
                .pickerStyle(.menu)
            }

            VStack(alignment: .leading, spacing: 6) {
                Text("نوع IP").font(.subheadline.weight(.semibold))
                Picker("نوع IP", selection: $state.ipMode) {
                    ForEach(IPMode.allCases) { m in Text(m.title).tag(m) }
                }
                .pickerStyle(.segmented)
                Text("اگر پروفایل کار نکرد (به‌خصوص روی ایرانسل) حالت «فقط IPv6» را امتحان کنید.")
                    .font(.caption).foregroundStyle(.secondary)
            }

            Button {
                UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                state.installViaSafari()
            } label: {
                Label("ساخت پروفایل و باز کردن در Safari", systemImage: "safari")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)

            if let url = state.shareURL {
                ShareLink(item: url) {
                    Label("ذخیره / اشتراک فایل پروفایل", systemImage: "square.and.arrow.up")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
            } else {
                Button { state.prepareShareFile() } label: {
                    Label("آماده‌سازی فایل برای ذخیره در Files", systemImage: "folder")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
            }

            Label("پروفایل کاملاً روی خود گوشی ساخته می‌شود و هیچ اطلاعاتی به اینترنت ارسال نمی‌شود.",
                  systemImage: "lock.shield")
                .font(.caption).foregroundStyle(.secondary)
        }
    }
}

// MARK: - تایمر هواپیما

struct AirplaneSection: View {
    @State private var remaining: Int? = nil
    @State private var finished = false
    @State private var task: Task<Void, Never>?

    var body: some View {
        VStack(spacing: 10) {
            if let r = remaining {
                Text(r.formatted())
                    .font(.system(size: 44, weight: .bold, design: .rounded))
                    .monospacedDigit()
                Text("حالت هواپیما روشن بماند…").font(.caption).foregroundStyle(.secondary)
            } else if finished {
                Label("حالا حالت هواپیما را خاموش کنید ✅", systemImage: "checkmark.circle.fill")
                    .foregroundStyle(.green).font(.subheadline.weight(.semibold))
            }

            Button {
                start()
            } label: {
                Label(remaining == nil ? "شروع شمارش ۵ ثانیه" : "در حال شمارش…", systemImage: "timer")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)
            .controlSize(.large)
            .disabled(remaining != nil)
        }
        .onDisappear { task?.cancel() }
    }

    private func start() {
        finished = false
        remaining = 5
        task = Task {
            for i in stride(from: 5, through: 1, by: -1) {
                await MainActor.run { remaining = i }
                try? await Task.sleep(nanoseconds: 1_000_000_000)
                if Task.isCancelled { return }
            }
            await MainActor.run {
                remaining = nil
                finished = true
                UINotificationFeedbackGenerator().notificationOccurred(.success)
            }
        }
    }
}

// MARK: - شورتکات

struct ShortcutSection: View {
    @EnvironmentObject var state: AppState

    var body: some View {
        VStack(spacing: 10) {
            Button { state.installShortcut() } label: {
                Label("نصب شورتکات Anten", systemImage: "square.and.arrow.down.on.square")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)

            Button { state.openShortcutsApp() } label: {
                Label("باز کردن اپ Shortcuts", systemImage: "bolt.fill")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)
            .controlSize(.large)
        }
    }
}
