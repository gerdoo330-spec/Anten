import Foundation

enum StepKind { case info, generate, airplane, shortcut }

struct Step: Identifiable {
    let id: Int
    let icon: String
    let title: String
    let lines: [String]
    var kind: StepKind = .info

    /// مراحل دقیقاً بر اساس README پروژه‌ی اصلی
    static let all: [Step] = [
        Step(id: 0, icon: "arrow.counterclockwise.circle",
             title: "ریست تنظیمات شبکه",
             lines: [
                "مسیر: Settings ← General ← Transfer or Reset iPhone ← Reset ← Reset Network Settings",
                "رمز گوشی را وارد و تایید کنید.",
                "توجه: رمز Wi‑Fi های ذخیره‌شده و VPN های قبلی پاک می‌شود."
             ]),
        Step(id: 1, icon: "square.and.arrow.down",
             title: "ساخت و دانلود پروفایل",
             lines: [
                "اپراتور خود را انتخاب کنید و دکمه را بزنید؛ Safari باز می‌شود.",
                "اگر پیام Allow برای دریافت فایل پیکربندی آمد، آن را تایید کنید.",
                "اگر نمی‌خواهید از Safari استفاده کنید، فایل را در Files ذخیره کنید و روی آن بزنید.",
                "هر بار که دکمه را می‌زنید یک UUID جدید و یکتا ساخته می‌شود؛ نیازی به رجیستر گوشی نیست."
             ], kind: .generate),
        Step(id: 2, icon: "checkmark.shield",
             title: "نصب پروفایل",
             lines: [
                "وارد Settings شوید؛ بالای صفحه گزینه‌ی Profile Downloaded دیده می‌شود.",
                "یا: Settings ← General ← VPN & Device Management",
                "پروفایل را انتخاب کنید، Install را بزنید و رمز دستگاه را وارد کنید.",
                "قبل از نصب پروفایل جدید، پروفایل قبلی را حذف کنید (تب «حذف و رفع مشکل»)."
             ]),
        Step(id: 3, icon: "antenna.radiowaves.left.and.right",
             title: "تنظیمات Cellular",
             lines: [
                "Settings ← Cellular ← Cellular Data Options",
                "گزینه‌ی Data Roaming را روشن کنید.",
                "Voice & Data را روی 5G یا LTE بگذارید و VoLTE را روشن کنید.",
                "سپس گوشی را کامل خاموش و روشن کنید تا آنتن برگردد."
             ]),
        Step(id: 4, icon: "airplane",
             title: "حالت هواپیما (روش تکمیلی)",
             lines: [
                "برای تثبیت سریع‌تر تنظیمات، یک‌بار حالت هواپیما را روشن کنید، ۵ ثانیه صبر کنید و خاموش کنید.",
                "تایمر زیر ۵ ثانیه را برایتان می‌شمارد."
             ], kind: .airplane),
        Step(id: 5, icon: "bolt.fill",
             title: "فعال‌سازی با شورتکات",
             lines: [
                "ابتدا شورتکات «Anten» را نصب کنید (Add Shortcut).",
                "بعد از داخل اپ Shortcuts روی Anten بزنید تا اجرا شود.",
                "اگر در طول روز آنتن قطع شد، فقط همین شورتکات را دوباره اجرا کنید."
             ], kind: .shortcut)
    ]
}
