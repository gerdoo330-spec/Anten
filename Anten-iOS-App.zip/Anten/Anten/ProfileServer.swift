import Foundation
import Network

/// یک سرور HTTP بسیار کوچک روی loopback (127.0.0.1).
/// iOS اجازه‌ی نصب مستقیم پروفایل از داخل اپ را نمی‌دهد؛ تنها راه رسمی این است که
/// Safari فایل .mobileconfig را با MIME مخصوص دریافت کند. این کلاس همین کار را انجام می‌دهد.
/// هیچ داده‌ای از دستگاه خارج نمی‌شود.
final class ProfileServer: @unchecked Sendable {
    static let path = "/antenna.mobileconfig"

    private let queue = DispatchQueue(label: "com.anten.profile-server")
    private var listener: NWListener?
    private var payload = Data()
    private var reported = false

    func start(payload: Data, completion: @escaping @Sendable (Result<URL, Error>) -> Void) {
        queue.async { [self] in
            stopLocked()
            self.payload = payload
            self.reported = false

            let params = NWParameters.tcp
            params.requiredInterfaceType = .loopback

            do {
                let l = try NWListener(using: params)
                l.stateUpdateHandler = { [weak self, weak l] state in
                    guard let self, let l else { return }
                    switch state {
                    case .ready:
                        guard !self.reported, let port = l.port?.rawValue else { return }
                        self.reported = true
                        completion(.success(URL(string: "http://127.0.0.1:\(port)\(Self.path)")!))
                        // بعد از ۹۰ ثانیه خودکار خاموش می‌شود
                        self.queue.asyncAfter(deadline: .now() + 90) { [weak self, weak l] in
                            if let self, let l, self.listener === l { self.stopLocked() }
                        }
                    case .failed(let error):
                        if !self.reported { self.reported = true; completion(.failure(error)) }
                        self.stopLocked()
                    default:
                        break
                    }
                }
                l.newConnectionHandler = { [weak self] connection in
                    self?.handle(connection)
                }
                self.listener = l
                l.start(queue: self.queue)
            } catch {
                completion(.failure(error))
            }
        }
    }

    func stop() { queue.async { [self] in stopLocked() } }

    private func stopLocked() {
        listener?.cancel()
        listener = nil
    }

    private func handle(_ connection: NWConnection) {
        connection.start(queue: queue)
        connection.receive(minimumIncompleteLength: 1, maximumLength: 8192) { [weak self] data, _, _, _ in
            guard let self else { connection.cancel(); return }
            let request = String(data: data ?? Data(), encoding: .utf8) ?? ""
            let firstLine = request.components(separatedBy: "\r\n").first ?? ""
            let ok = firstLine.hasPrefix("GET \(Self.path)")

            let body = ok ? self.payload : Data("Not Found".utf8)
            var head = ok ? "HTTP/1.1 200 OK\r\n" : "HTTP/1.1 404 Not Found\r\n"
            head += "Content-Type: \(ok ? "application/x-apple-aspen-config" : "text/plain")\r\n"
            head += "Content-Length: \(body.count)\r\n"
            head += "Cache-Control: no-store\r\n"
            head += "Connection: close\r\n\r\n"

            var out = Data(head.utf8)
            out.append(body)
            connection.send(content: out, completion: .contentProcessed { _ in connection.cancel() })
        }
    }
}
