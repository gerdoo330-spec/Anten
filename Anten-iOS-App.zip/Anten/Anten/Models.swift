import Foundation

// MARK: - اپراتورها

enum Carrier: String, CaseIterable, Identifiable {
    case mcinet, mtnirancell, rightel, aptel, samantel, shatelmobile

    var id: String { rawValue }
    var apn: String { rawValue }

    var persianName: String {
        switch self {
        case .mcinet: return "همراه اول"
        case .mtnirancell: return "ایرانسل"
        case .rightel: return "رایتل"
        case .aptel: return "آپتل"
        case .samantel: return "سامانتل"
        case .shatelmobile: return "شاتل موبایل"
        }
    }

    var englishName: String {
        switch self {
        case .mcinet: return "Hamrah Aval"
        case .mtnirancell: return "Irancell"
        case .rightel: return "Rightel"
        case .aptel: return "Aptel"
        case .samantel: return "Samantel"
        case .shatelmobile: return "Shatel Mobile"
        }
    }

    /// نام نمایشی داخل پروفایل (مثل نسخه‌ی وب)
    var displayName: String { "\(englishName) (\(persianName))" }
}

// MARK: - نوع IP

enum IPMode: Int, CaseIterable, Identifiable {
    case dual = 3      // IPv4 + IPv6 (پیش‌فرض)
    case ipv6 = 2      // فقط IPv6 (مناسب مشکل اینترنت ایرانسل)

    var id: Int { rawValue }
    var title: String {
        switch self {
        case .dual: return "IPv4 + IPv6"
        case .ipv6: return "فقط IPv6"
        }
    }
}

// MARK: - ساخت پروفایل .mobileconfig

enum ProfileBuilder {
    /// دقیقاً همان ساختار نسخه‌ی وب؛ هر بار با UUID یکتا.
    /// از PropertyListSerialization استفاده می‌شود تا کاراکترهای خاص XML به‌درستی escape شوند.
    static func build(carrier: Carrier, ipMode: IPMode) throws -> Data {
        let name = carrier.displayName
        let mask = ipMode.rawValue

        let apn: [String: Any] = [
            "Name": name,
            "APN": carrier.apn,
            "AuthenticationType": "PAP",
            "AllowedProtocolMask": mask,
            "AllowedProtocolMaskInRoaming": mask,
            "AllowedProtocolMaskInDomesticRoaming": mask,
            "DefaultProtocolMask": mask,
            "EnableXLAT464": true
        ]

        let attach: [String: Any] = [
            "Name": name,
            "AllowedProtocolMask": mask,
            "AuthenticationType": "PAP"
        ]

        let cellular: [String: Any] = [
            "PayloadDescription": "Configures APN settings",
            "PayloadDisplayName": "\(name) APN",
            "PayloadIdentifier": "com.anten.apn.\(carrier.apn)",
            "PayloadOrganization": name,
            "PayloadType": "com.apple.cellular",
            "PayloadUUID": UUID().uuidString,
            "PayloadVersion": 1,
            "APNs": [apn],
            "AttachAPN": attach
        ]

        let root: [String: Any] = [
            "PayloadContent": [cellular],
            "PayloadDisplayName": "\(name) APN Configuration",
            "PayloadIdentifier": "com.anten.apn.\(carrier.apn).profile",
            "PayloadRemovalDisallowed": false,
            "PayloadType": "Configuration",
            "PayloadUUID": UUID().uuidString,
            "PayloadVersion": 1
        ]

        return try PropertyListSerialization.data(fromPropertyList: root, format: .xml, options: 0)
    }
}
