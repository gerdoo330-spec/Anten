import SwiftUI
import UIKit

struct Banner: Identifiable {
    let id = UUID()
    let title: String
    let message: String
}

@MainActor
final class AppState: ObservableObject {
    static let shortcutURL = URL(string: "https://www.icloud.com/shortcuts/9b2f6b908fb74058b2b1bf3ed4d08451")!

    private enum Key {
        static let carrier = "carrier"
        static let ipMode = "ipMode"
        static let done = "doneSteps"
    }

    @Published var carrier: Carrier {
        didSet { UserDefaults.standard.set(carrier.rawValue, forKey: Key.carrier) }
    }
    @Published var ipMode: IPMode {
        didSet { UserDefaults.standard.set(ipMode.rawValue, forKey: Key.ipMode) }
    }
    @Published private(set) var done: Set<Int>
    @Published var banner: Banner?
    @Published var shareURL: URL?

    private let server = ProfileServer()
    private var bgTask: UIBackgroundTaskIdentifier = .invalid

    init() {
        let d = UserDefaults.standard
        carrier = Carrier(rawValue: d.string(forKey: Key.carrier) ?? "") ?? .mcinet
        ipMode = IPMode(rawValue: d.integer(forKey: Key.ipMode)) ?? .dual
        done = Set((d.array(forKey: Key.done) as? [Int]) ?? [])
    }

    // MARK: پیشرفت مراحل

    func isDone(_ step: Int) -> Bool { done.contains(step) }

    func toggle(_ step: Int) {
        if done.contains(step) { done.remove(step) } else { done.insert(step) }
        UserDefaults.standard.set(Array(done), forKey: Key.done)
        UISelectionFeedbackGenerator().selectionChanged()
    }

    func resetProgress() {
        done = []
        UserDefaults.standard.set([Int](), forKey: Key.done)
    }

    // MARK: پروفایل

    /// ساخت پروفایل جدید (UUID تازه) و باز کردن آن در Safari
    func installViaSafari() {
        do {
            let data = try ProfileBuilder.build(carrier: carrier, ipMode: ipMode)
            shareURL = writeTemp(data)

            // اپ تا چند ثانیه بعد از رفتن به پس‌زمینه سرور را زنده نگه دارد
            beginBackground()

            server.start(payload: data) { [weak self] result in
                Task { @MainActor in
                    guard let self else { return }
                    switch result {
                    case .success(let url):
                        UIApplication.shared.open(url) { ok in
                            if !ok {
                                Task { @MainActor in
                                    self.banner = Banner(title: "باز نشد",
                                                         message: "مرورگر پیش‌فرض را روی Safari بگذارید یا از دکمه‌ی «ذخیره/اشتراک فایل» استفاده کنید.")
                                }
                            }
                        }
                    case .failure(let error):
                        self.banner = Banner(title: "خطا در آماده‌سازی",
                                             message: error.localizedDescription)
                    }
                }
            }
        } catch {
            banner = Banner(title: "ساخت پروفایل ناموفق بود", message: error.localizedDescription)
        }
    }

    /// ساخت فایل برای ذخیره در Files / AirDrop
    func prepareShareFile() {
        guard let data = try? ProfileBuilder.build(carrier: carrier, ipMode: ipMode) else { return }
        shareURL = writeTemp(data)
    }

    private func writeTemp(_ data: Data) -> URL? {
        let safe = carrier.englishName.replacingOccurrences(of: " ", with: "_")
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("\(safe)_APN.mobileconfig")
        do { try data.write(to: url, options: .atomic); return url } catch { return nil }
    }

    private func beginBackground() {
        endBackground()
        bgTask = UIApplication.shared.beginBackgroundTask(withName: "profile-server") { [weak self] in
            Task { @MainActor in self?.endBackground() }
        }
        Task { [weak self] in
            try? await Task.sleep(nanoseconds: 60 * 1_000_000_000)
            await MainActor.run { self?.endBackground() }
        }
    }

    private func endBackground() {
        if bgTask != .invalid {
            UIApplication.shared.endBackgroundTask(bgTask)
            bgTask = .invalid
        }
    }

    // MARK: میان‌برها

    func open(_ url: URL) { UIApplication.shared.open(url) }
    func openShortcutsApp() { open(URL(string: "shortcuts://")!) }
    func installShortcut() { open(Self.shortcutURL) }
}
