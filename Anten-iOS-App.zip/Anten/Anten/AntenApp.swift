import SwiftUI

@main
struct AntenApp: App {
    @StateObject private var state = AppState()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(state)
                .environment(\.layoutDirection, .rightToLeft)
                .environment(\.locale, Locale(identifier: "fa_IR"))
        }
    }
}

struct RootView: View {
    @EnvironmentObject var state: AppState

    var body: some View {
        TabView {
            StepsView()
                .tabItem { Label("مراحل", systemImage: "list.number") }
            TipsView()
                .tabItem { Label("نکات", systemImage: "lightbulb") }
            HelpView()
                .tabItem { Label("حذف و رفع مشکل", systemImage: "wrench.and.screwdriver") }
        }
        .alert(item: $state.banner) { b in
            Alert(title: Text(b.title), message: Text(b.message), dismissButton: .default(Text("باشه")))
        }
    }
}
