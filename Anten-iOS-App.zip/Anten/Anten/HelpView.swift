import SwiftUI

struct HelpView: View {
    @EnvironmentObject var state: AppState

    var body: some View {
        NavigationStack {
            List {
                Section("راهنمای حذف پروفایل") {
                    numbered(1, "به مسیر Settings ← General ← VPN & Device Management بروید.")
                    numbered(2, "پروفایل مورد نظر را انتخاب کنید.")
                    numbered(3, "روی Remove Profile بزنید و رمز دستگاه را وارد کنید.")
                }

                Section("رفع مشکل رایج") {
                    bullet("پروفایل نصب نمی‌شود: مطمئن شوید فایل را با Safari دانلود کرده‌اید و مرورگر پیش‌فرض Safari است.")
                    bullet("آنتن برنگشت: Reset Network Settings را انجام دهید، پروفایل قبلی را حذف کنید، پروفایل تازه بسازید و گوشی را ری‌استارت کنید.")
                    bullet("اینترنت ندارید ولی آنتن هست: نوع IP را روی «فقط IPv6» بگذارید و دوباره نصب کنید.")
                    bullet("بعد از نصب، Data Roaming و VoLTE روشن و شبکه روی 5G/LTE باشد.")
                }

                Section("درباره") {
                    Text("این اپ ابزار بومی (Native) نسخه‌ی وب پروژه‌ی «iPhone-antenna-profile» است و همان پروفایل APN را بدون نیاز به اینترنت و روی خود گوشی می‌سازد.")
                        .font(.footnote).foregroundStyle(.secondary)
                    Link("توسعه‌دهنده اصلی: میلاد طحانیان", destination: URL(string: "https://github.com/miladtahanian")!)
                    Link("فورک و دیباگ: شنتیا اسلامی", destination: URL(string: "https://github.com/ishantia")!)
                    Text("این ابزار مستقل است و هیچ ارتباطی با اپراتورهای یادشده یا اپل ندارد.")
                        .font(.caption).foregroundStyle(.tertiary)
                }
            }
            .navigationTitle("حذف و رفع مشکل")
        }
    }

    private func numbered(_ n: Int, _ text: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 10) {
            Text(n.formatted()).font(.caption.bold()).foregroundStyle(.white)
                .frame(width: 22, height: 22).background(Color.accentColor, in: Circle())
            Text(text).font(.subheadline)
        }
    }

    private func bullet(_ text: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Text("•").foregroundStyle(.secondary)
            Text(text).font(.subheadline)
        }
    }
}
