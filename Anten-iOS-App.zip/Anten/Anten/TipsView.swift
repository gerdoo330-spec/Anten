import SwiftUI

struct TipsView: View {
    private let tips: [(String, String)] = [
        ("📡", "برای بازگشت بهتر آنتن، شبکه را روی «همراه اول» تنظیم کنید."),
        ("🚫", "از دو سیم‌کارت به‌صورت همزمان در گوشی استفاده نکنید."),
        ("🌐", "اگر پروفایل کار نکرد، با UUID جدید دوباره تست کنید (دکمه‌ی ساخت پروفایل هر بار UUID تازه می‌سازد). برای مشکل اینترنت، به‌خصوص ایرانسل، نوع IP را روی «فقط IPv6» بگذارید."),
        ("📶", "حتماً حالت شبکه را روی 5G تنظیم کنید."),
        ("🌙", "اگر از نیمه‌شب آنتن ندارید، شبکه را روی 2G بگذارید؛ در برخی موارد آنتن به‌صورت خودکار تا ساعت ۸ صبح برمی‌گردد.")
    ]

    var body: some View {
        NavigationStack {
            List {
                Section {
                    ForEach(Array(tips.enumerated()), id: \.offset) { i, tip in
                        HStack(alignment: .top, spacing: 12) {
                            Text(tip.0).font(.title3)
                            VStack(alignment: .leading, spacing: 2) {
                                Text("نکته \((i + 1).formatted())").font(.caption).foregroundStyle(.secondary)
                                Text(tip.1).font(.subheadline)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }
                Section {
                    Label("پیش از تست هر پروفایل جدید، حتماً پروفایل قبلی را حذف کنید.",
                          systemImage: "exclamationmark.triangle.fill")
                        .foregroundStyle(.orange)
                        .font(.subheadline)
                }
            }
            .navigationTitle("نکات مهم")
        }
    }
}
